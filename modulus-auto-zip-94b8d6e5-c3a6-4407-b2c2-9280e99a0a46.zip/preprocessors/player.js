/* player */
//{ url: insta_vid_list[random].url, username: insta_vid_list[random].username}