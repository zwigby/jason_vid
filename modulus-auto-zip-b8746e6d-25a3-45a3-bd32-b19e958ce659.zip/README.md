# New Solidus Test

## Working On This Website

After first cloning this repository, you'll need to run `npm install` in the base directory (that's the one with `package.json` in it) to install all the modules the [Grunt](http://gruntjs.com) scripts depend on. Doing this will enable the `grunt dev` command, which will do a [variety of development related tasks](https://github.com/SparkartGroupInc/solidus-site-template#grunt-tasks) for you.